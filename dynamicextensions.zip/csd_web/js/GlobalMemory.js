/*
 * Used for sharing variables within a callback anonymous method or in general globaly accessible variables.
 */
var GlobalMemory = {

	nodeCounter : 2,
	sequenceNumCntr : 0,
	treeView : null,
	/*formView : null,
	mainTabBarView : null,
	currentFieldView : null,
	designModeViewPointer : null,*/
	pvCounter : 0,
	/*carousel : null,
	advancedControlsView : null,*/
	formulaCounter : 0,
	currentBufferControlModel : null,
	generalFlag : false,
	controlName : null,
	skipRulesCounter : 1,
	editForm : false,
	globalLabelPosition : "LEFT",
	formulae : {},
	skipRuleId : null
}