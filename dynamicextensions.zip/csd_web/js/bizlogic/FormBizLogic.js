/**
 * 
 */

var FormBizLogic = {
		
		loadPreview : function() {
			$('#previewFrame').prop('src', "csd_web/pages/preview.jsp");
			$("#formWaitingImage").hide();
		}
}